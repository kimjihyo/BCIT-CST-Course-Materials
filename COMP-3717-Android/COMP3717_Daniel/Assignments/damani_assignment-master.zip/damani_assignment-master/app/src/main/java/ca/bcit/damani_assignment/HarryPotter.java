package ca.bcit.damani_assignment;

import java.util.ArrayList;
import java.util.List;

public class HarryPotter {

        private String title;
        private String type;
        private String id;


        public void setTitle(String title){
            this.title = title;
        }
        public String getTitle(){
            return this.title;
        }

        private String identifier;

        public void setType(String type){
            this.type = type;
        }
        public String getType(){
            return this.type;
        }
        public void setIdentifier(String identifier){
            this.identifier = identifier;
        }
        public String getIdentifier(){
            return this.identifier;
        }


        private String smallThumbnail;

        private String thumbnail;

        public void setSmallThumbnail(String smallThumbnail){
            this.smallThumbnail = smallThumbnail;
        }
        public String getSmallThumbnail(){
            return this.smallThumbnail;
        }
        public void setThumbnail(String thumbnail){
            this.thumbnail = thumbnail;
        }
        public String getThumbnail(){
            return this.thumbnail;
        }



        private String authors;

        private String publisher;

       // private DateTime publishedDate;

        private String description;

       // private List<IndustryIdentifiers> industryIdentifiers;

        private List<String> categories;


        //private ImageLinks imageLinks;





        public void setAuthors(String authors){
            this.authors = authors;
        }
        public String getAuthors(){
            return this.authors;
        }
        public void setPublisher(String publisher){
            this.publisher = publisher;
        }
        public String getPublisher(){
            return this.publisher;
        }
//        public void setPublishedDate(DateTime publishedDate){
//            this.publishedDate = publishedDate;
//        }
//        public DateTime getPublishedDate(){
//            return this.publishedDate;
//        }
        public void setDescription(String description){
        this.description = description;
        }
        public String getDescription(){
            return this.description;
        }

    public void setId(String id){
        this.id = id;
    }
    public String getId(){
        return this.id;
    }


}
