package ca.bcit.damani_assignment;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;


import ca.bcit.damani_assignment.HarryPotter;

public class HPAdapter extends ArrayAdapter<HarryPotter> {
        Context _context;
        public HPAdapter(Context context, ArrayList<HarryPotter> books) {
            super(context, 0, books);
            _context = context;
        }


    @Override
        public View getView(int position, View convertView,  ViewGroup parent) {
            final Activity activity = (Activity) _context;
            HarryPotter book = getItem(position);
            if (convertView == null) {
                convertView = LayoutInflater.from(getContext()).inflate(R.layout.list_row_layout, parent, false);
            }

            TextView bookTitle = convertView.findViewById(R.id.title);
            bookTitle.setText(book.getTitle());

            return convertView;
        }
    }


