package ca.bcit.damani_assignment;

import androidx.appcompat.app.AppCompatActivity;
import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.widget.ListView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private String TAG = MainActivity.class.getSimpleName();
    private ProgressDialog pDialog;
    private ListView lv;
    private static String SERVICE_URL = "https://www.googleapis.com/books/v1/volumes?q=harry+potter";
    private ArrayList<HarryPotter> bookList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        bookList = new ArrayList<HarryPotter>();
        lv = findViewById(R.id.bookList);
        new GetContacts().execute();
    }


    private class GetContacts extends AsyncTask<Void, Void, Void> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            // Showing progress dialog
            pDialog = new ProgressDialog(MainActivity.this);
            pDialog.setMessage("Please wait...");
            pDialog.setCancelable(false);
            pDialog.show();

        }

        @Override
        protected Void doInBackground(Void... arg0) {
            HttpHandler sh = new HttpHandler();
            String jsonStr = null;

            jsonStr = sh.makeServiceCall(SERVICE_URL);


            Log.e(TAG, "Response from url: " + jsonStr);

            if (jsonStr != null) {
                jsonStr = "[" + jsonStr +"]";
                try {

                    JSONArray bookJsonArray = new JSONArray(jsonStr);


                    for (int i = 0; i < 10; i++) { //fix this
                        JSONObject b = bookJsonArray.getJSONObject(0);
                        JSONArray item =  b.getJSONArray("items");
                        JSONObject volume = item.getJSONObject(i);
                        JSONObject volumeKey = volume.getJSONObject("volumeInfo");
                        String titleName = volumeKey.getString("title");


                        //String title = b.getString("title");
                               // .getJSONObject("title").getString("title");
                        //String title = b.getString("title");
//                        String authors = b.getString("authors");
//                        String publisher = b.getString("publisher");
//                        String description = b.getString("description");
//                        String isbn = b.getString("ISBN");
//                        String date = b.getString("published date");
                        //String pictureUrl = b.getString("pictureUrl");


                        HarryPotter book = new HarryPotter();

                        book.setTitle(titleName);
//                        book.setAuthors(authors);
//                        book.setPublisher(publisher);
//                        book.setDescription(description);
                        //book.setISBN();
                        //book.setPublishedDate(dtae);
                       // book.setPictureUrl(pictureUrl);

                        // adding contact to contact list
                        bookList.add(book);
                    }
                } catch (final JSONException e) {
                    Log.e(TAG, "Json parsing error: " + e.getMessage());
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(getApplicationContext(),
                                    "Json parsing error: " + e.getMessage(),
                                    Toast.LENGTH_LONG)
                                    .show();
                        }
                    });
                }
            } else {
                Log.e(TAG, "Couldn't get json");
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(getApplicationContext(),
                                "Couldn't get json from server.",
                                Toast.LENGTH_LONG)
                                .show();
                    }
                });

            }
            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);

            if (pDialog.isShowing())
                pDialog.dismiss();

            HPAdapter adapter = new HPAdapter(MainActivity.this, bookList);
            lv.setAdapter(adapter);
        }
    }
}